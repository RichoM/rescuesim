from controller import Robot
import struct

TIME_STEP = 32
MAX_VEL = 6.28

robot = Robot()

rI = robot.getDevice("ruedaI motor")
rI.setPosition(float("inf"))

rD = robot.getDevice("ruedaD motor")
rD.setPosition(float("inf"))
# camLeft=robot.getDevice("cameraLeft")
# camRight=robot.getDevice("cameraRight")
camF=robot.getDevice("camaraFrente")
# camLeft.enable(TIME_STEP)
# camRight.enable(TIME_STEP)
camF.enable(TIME_STEP)

t0 = robot.getTime()
rI.setVelocity(0.5*MAX_VEL)
rD.setVelocity(-0.5*MAX_VEL)

while robot.step(TIME_STEP) != -1:
    if robot.getTime() - t0 > 5:
        break

rI.setVelocity(0)
rD.setVelocity(0)