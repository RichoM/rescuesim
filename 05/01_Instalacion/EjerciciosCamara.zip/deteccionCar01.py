import cv2
import numpy as np

# Voy a ejecutarlo para todas las imágenes de carteles que tengo
for i in range(1,23):
    analizar=f'capturas\\car{str(i).rjust(3,"0")}.png'
    print(analizar)
    imagen=cv2.imread(analizar)

    # Comprimimos en unas pocas líneas lo que hicimos en el programa anterior
    gris=cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
    ret, thresh=cv2.threshold(gris, 140, 255, cv2.THRESH_BINARY)
    contornos, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # minAreaRect es una función que nos permite obtener el rectángulo más grande que encuentre en los contornos
    # Detecta el rectángulo definido por los contornos
    # Me devuelve ((xCentro,yCentro), (ancho,alto), angulo) 
    approx=cv2.minAreaRect(contornos[0])
    angulo=approx[2]
    # En este caso, los que no están completos no dan 45 de rotación
    
    if abs(angulo)==45:
        # Voy a rotar thresh para volver a buscar el cartel, e imagen para cortar el cartel en color
        alto, ancho=thresh.shape[0], thresh.shape[1]
        # genero la matriz de rotación
        M=cv2.getRotationMatrix2D((ancho/2,alto/2),angulo,1)
        
        # warpAffine rota la imagen según la matriz de rotación (con salida del tamaño indicado)
        # Rotamos los dos para poder buscar nuevamente en thresh_rot el contorno, 
        # y luego cortar, con el contorno encontrado, el cartel de image_rot
        thresh_rot=cv2.warpAffine(thresh,M,(ancho,alto))
        imagen_rot=cv2.warpAffine(imagen,M,(ancho,alto))
        
        #Vuelvo a buscar los contornos en el thresh rotado
        contornos, hierarchy = cv2.findContours(thresh_rot, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        #Y vuelvo a buscar el rectángulo
        approx=cv2.minAreaRect(contornos[0])
        x=int(approx[0][0])
        y=int(approx[0][1])
        mitadAncho=int(approx[1][0]/2)
        mitadAlto=int(approx[1][1]/2)
        
        # Lo corto, y ya tengo sólo el cartel, y en colores
        rect=imagen_rot[y-mitadAlto:y+mitadAlto, x-mitadAncho:x+mitadAncho]    
        cv2.imshow("Cartel", imagen_rot)
        cv2.imshow("Threshrot", thresh_rot)
        cv2.imshow("Cartel rotado", rect)
        
    # Escribo el ángulo en la imagen
    cv2.putText(imagen, f'{angulo}', (10,20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1)
    cv2.imshow('Rotacion', imagen)
    
    cv2.waitKey(0)
    cv2.destroyAllWindows()

