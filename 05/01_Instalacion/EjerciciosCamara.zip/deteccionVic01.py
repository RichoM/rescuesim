import cv2
import numpy as np

analizar='capturas\\vic002.png'
imagen=cv2.imread(analizar)
cv2.imshow("Original", imagen)

#Algunos procesos que podemos hacerle a la imagen
# Convertir en escala de grises (0 es negro, 255 es blanco)
# Tal vez es bueno pasarlo a escala de grises

gris=cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
cv2.imshow("Gris", gris)

# Aplico un threshold binario, es decir, paso cada pixel a negro o blanco según un umbral
# En este caso voy a decir que los pixeles que están entre 0 y 80 vayan a negro
# y los que están por encima de 80 vayan al valor máximo indicado por el 3er parámetro (255) 
# En síntesis, exagero bien las diferencias
# el primer elemento que devuelve (ret) es el umbral utilizado
ret, thresh=cv2.threshold(gris, 140, 255, cv2.THRESH_BINARY)
cv2.imshow("Thresh", thresh)
# print(ret)  # Valor del umbral

# Ahora quiero detectar el rectángulo del cartel
# En contornos obtengo todos los puntitos que forman cada contorno. Es decir, obtengo contornos
# donde cada uno de ellos es una lista de puntos
contornos, jerarquia = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
print(f"Número de contornos: {len(contornos)}")
numero=1
for cont in contornos:
    print(f"Contorno número: {numero} - Cantidad de puntos: {len(cont)}")
    numero+=1
    
#dibujamos los contornos en imagen con color rojo y línea de ancho 2 (no los dibujo en thresh porque no tengo colores!)

cv2.drawContours(imagen, contornos, -1, (0, 0, 255), 2)
# Veamos cuántos contornos tenemos y cuántos puntos tienen esos contornos. Esperamos tener
# un único contorno y una cantidad de puntos baja en ese contorno

cv2.imshow("Contornos", imagen)
cv2.waitKey(0)

# Probemos con distintas imágenes v02, v03, etc.
# ¿Cuándo pareciera que estoy viendo el cartel completo? 