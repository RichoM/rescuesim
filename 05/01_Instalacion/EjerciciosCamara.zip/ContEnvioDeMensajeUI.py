from controller import Robot
import math
import struct

# Este ejemplo está creado para mostrar el envío de mensajes. 
# Está completamente hardcodeado para que muestre diferentes casos en el mapa Camara.wbt
# y con un algoritmo de navegación determinado. 
# Deben vincular el envío de mensajes con los resultados de la detección de víctimas y carteles.

TIME_STEP = 32
MAX_VEL = 6.28
robot = Robot()


position = None
initialPosition = None
rotation = 0
beginTime = robot.getTime()
currentTime = beginTime
deltaTime = 0
pasoActual=0

x = 0
y = 0

# El emitter es el componente que nos permite enviar mensajes al supervisor

emitter=robot.getDevice("emitter")

gps=robot.getDevice("gps")
gps.enable(TIME_STEP)

iu=robot.getDevice("inertial_unit")
iu.enable(TIME_STEP)

ruedaI = robot.getDevice("ruedaI motor")
ruedaI.setPosition(float("inf"))

ruedaD = robot.getDevice("ruedaD motor")
ruedaD.setPosition(float("inf"))

di = robot.getDevice("distanciaIzquierda")
di.enable(TIME_STEP)

dd = robot.getDevice("distanciaDerecha")
dd.enable(TIME_STEP)

df=robot.getDevice("distanciaFrente")
df.enable(TIME_STEP)

camI=robot.getDevice("camaraIzquierda")
camI.enable(TIME_STEP)

camD=robot.getDevice("camaraDerecha")
camD.enable(TIME_STEP)

camF=robot.getDevice("camaraFrente")
camF.enable(TIME_STEP)

def updatePosition():
    global position
    x, _, y = gps.getValues()
    position = {"x": x, "y": y}

def updateRotation():
    global rotation
    _, _, rotation = iu.getRollPitchYaw()
    # OPCIONAL: Calcular el valor de rotación en grados y mostrarlo en consola
    # degrees = rotation * 180/math.pi
    # print(f"Velocidad: {vel:.3f} rad/s")
    # print(f"Rotación: {rotation:.3f} rad ({degrees:.3f} deg)")
    # print("================")
    
def updateVars():
    updatePosition()
    updateRotation()
    
    

def step():
    result = robot.step(TIME_STEP)
    updateVars()
    return result

def delay(ms):
    initTime = robot.getTime()
    while step() != -1:
        if (robot.getTime() - initTime) * 1000.0 >= ms:
            break
        
def angle_diff(a, b):
    clockwise = (a - b) % math.tau
    counterclockwise = (b - a) % math.tau
    return min(clockwise, counterclockwise)

def girar(rad):
    lastRot = rotation
    deltaRot = 0

    while step() != -1:
        deltaRot += angle_diff(rotation, lastRot)
        lastRot = rotation

        diff = angle_diff(deltaRot, abs(rad))

        if diff <= 0.01:
            break

        mul = (4/math.pi) * diff
        mul = min(max(mul, 0.1), 1)

        if rad > 0:
            ruedaI.setVelocity(mul*MAX_VEL)
            ruedaD.setVelocity(-mul*MAX_VEL)
        else:
            ruedaI.setVelocity(-mul*MAX_VEL)
            ruedaD.setVelocity(mul*MAX_VEL)



    ruedaI.setVelocity(0)
    ruedaD.setVelocity(0)

def dist(pt1, pt2):
    return math.sqrt((pt2["x"]-pt1["x"])**2 + (pt2["y"]-pt1["y"])**2)

def parar():
    ruedaI.setVelocity(0)
    ruedaD.setVelocity(0)
    
def avanzar(distance):
    initPos = position

    while step() != -1:
        diff = abs(distance) - dist(position, initPos) 

        vel = min(max(diff/0.01, 0.1), 1)
        if distance < 0: vel *= -1
        
        ruedaI.setVelocity(vel*MAX_VEL)
        ruedaD.setVelocity(vel*MAX_VEL)

        if diff < 0.001:
            break
    
    parar()

def enviarMensaje(pos1, pos2, letra):
    let=bytes(letra, 'utf-8') # Convertimos la letra a bytes para poder enviarla en la estructura
    # print("Enviando mensaje con posiciones:", pos1, pos2, let)
    mensaje=struct.pack("i i c", pos1, pos2, let) # estructura el mensaje en el formato correcto
    # print(f"Mensaje: {mensaje}")
    emitter.send(mensaje)

def enviarMensajeVoC(tipo):
    parar()
    delay(1200) # Debemos hacer una pausa antes de enviar el mensaje
    enviarMensaje(int(position["x"]*100), int(position["y"]*100), tipo)

parar()
step() #Ejecuto una vez la simulación para tener valores iniciales de sensores
initialPosition = position

while step() != -1:
    print(f"Paso: {pasoActual}")
    if(pasoActual==1):
        print("Voy a avisar que veo una U")
        enviarMensajeVoC("U")
    if(pasoActual==2):
        print("Voy a avisar que veo una S")
        enviarMensajeVoC("S")
    if(pasoActual==4):
        print("A propósito voy a avisar que veo U cuando es H")
        enviarMensajeVoC("U")
    if(pasoActual==9):
        print("Voy a avisar que veo una F cuando no hay nada")
        enviarMensajeVoC("F")
    if(pasoActual==10):
        print("Voy a avisar que veo una F")
        enviarMensajeVoC("F") # Debía ser U
    if(pasoActual==13):
        print("Voy a avisar que veo una H cuando es una F")
        enviarMensajeVoC("H") # Debía ser F
    if(pasoActual==14):
        print("Voy a avisar que veo una P")
        enviarMensajeVoC("P")
    if(pasoActual==15):
        print("Voy a avisar que veo una F")
        enviarMensajeVoC("F")
    if(pasoActual==17):
        print("Voy a avisar que veo una O cuando en realidad es P")
        enviarMensajeVoC("O")
    if(pasoActual==19):
        print("Voy a avisar que veo una C")
        enviarMensajeVoC("C")
    if(pasoActual==22):
        print("Voy a avisar que veo una O")
        enviarMensajeVoC("O")
                
        
    pasoActual+=1
    
    delay(2000)
    distI=di.getValue()
    distD=dd.getValue()
    distF=df.getValue()
    print(distI, distF, distD)

    if(distI>0.13):
        girar(-0.25*math.tau) #giro a la izquierda 90 grados
        avanzar(0.12) #medida de un mosaico
    elif(distF<0.13):
        girar(0.25*math.tau) #giro a la derecha 90 grados
    else:
        avanzar(0.12) #medida de un mosaico

    delay(200)
