from controller import Robot
import math


TIME_STEP = 32
MAX_VEL = 6.28

robot = Robot()

iu=robot.getDevice("inertial_unit")
iu.enable(TIME_STEP)

ruedaI = robot.getDevice("ruedaI motor")
ruedaI.setPosition(float("inf"))

ruedaD = robot.getDevice("ruedaD motor")
ruedaD.setPosition(float("inf"))

rotation=0

def updateRotation():
    global rotation
    _, _, rotation = iu.getRollPitchYaw()

def step():
    result = robot.step(TIME_STEP)
    updateRotation()
    return result

def delay(ms):
    initTime = robot.getTime()
    while step() != -1:
        if (robot.getTime() - initTime) * 1000.0 >= ms:
            break

def angle_diff(a, b):
    clockwise = (a - b) % math.tau
    counterclockwise = (b - a) % math.tau
    return min(clockwise, counterclockwise)

def girar(rad):
    lastRot = rotation
    deltaRot = 0

    while step() != -1:
        deltaRot += angle_diff(rotation, lastRot)
        lastRot = rotation

        diff = angle_diff(deltaRot, abs(rad))

        mul = (5/math.pi) * diff
        mul = min(max(mul, 0.1), 1)

        if rad > 0:
            ruedaI.setVelocity(mul*MAX_VEL)
            ruedaD.setVelocity(-mul*MAX_VEL)
        else:
            ruedaI.setVelocity(-mul*MAX_VEL)
            ruedaD.setVelocity(mul*MAX_VEL)

        if diff <= 0.01:
            break

    ruedaI.setVelocity(0)
    ruedaD.setVelocity(0)

step()
updateRotation()

while robot.step() != -1:
    girar(math.pi/2)
    delay(500)
    girar(-math.pi/2)
    delay(500)